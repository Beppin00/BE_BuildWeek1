package it.epicode.bw.models;

public enum DurataAbbonamento {
	SETTIMANALE, 
	MENSILE
}
