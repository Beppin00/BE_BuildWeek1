package it.epicode.bw.models;

public enum StatoDistributore {
	ATTIVO, 
	INATTIVO
}
