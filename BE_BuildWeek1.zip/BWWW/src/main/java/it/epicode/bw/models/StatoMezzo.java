package it.epicode.bw.models;

public enum StatoMezzo {
	InSERVIZIO,
	InMANUTENZIONE
}
